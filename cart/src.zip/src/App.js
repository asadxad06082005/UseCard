import React, { useContext } from "react";
import { Routes, Route } from "react-router-dom";
import About from "./components/About/About";
import NavBar from "./components/NavBar/NavBar";
import Home from "./components/pages/Home";
import ShoppingCards from "./components/pages/ShoppingCards";

function App() {
  return (
    <div className="App">
      <NavBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/shoppingCard" element={<ShoppingCards />} />
        <Route path="/:id" element={<About />}/>
      </Routes>
    </div>
  );
}

export default App;
