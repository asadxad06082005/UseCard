import React from "react";

const ShoppingCards = () => {
  return <div>ShoppingCards</div>;
};

export default ShoppingCards;
