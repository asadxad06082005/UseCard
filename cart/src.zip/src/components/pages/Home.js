import React, { useContext } from "react";
import { AppContext } from "../../context";
import { Link } from "react-router-dom";
import style from "./Home.css";

const Home = () => {
  const { array } = useContext(AppContext);
  console.log(array);
  return (
    <div>
      <div className="container">
        <div className="row">
          <input
            type="search"
            name="search"
            placeholder="Search Something"
            style={{
              width: "70%",
              textAlign: "center",
              outline: "none",
              margin: "20px auto",
              padding: "15px",
            }}
          />
          {array.map((el) => {
            return (
              <div className="col-lg-4 col-md-6 col-sm-12">
                <div
                  class="card"
                  style={{
                    width: "22rem",
                    height: "600px",
                    marginTop: "30px",
                    textAlign: "center",
                  }}
                >
                  <img src={el.strDrinkThumb} class="card-img-top" />
                  <div class="card-body">
                    <h5 class="card-title">{el.strGlass}</h5>
                    <p class="card-text">{el.strInstructionsDE}</p>
                    <Link to={`/${el.idDrink}`} class="btn btn-outline-secondary">
                      More Info
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
export default Home;
