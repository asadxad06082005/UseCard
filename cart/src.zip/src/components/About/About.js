import React, { useContext } from "react";
import { useParams } from "react-router-dom";
import { AppContext } from "../../context";
import "./About.css";

const About = () => {
  const { array } = useContext(AppContext);
  const param = useParams();
  const currentData = array.find((el) => {
    return el.idDrink === param.id;
  });
  return (
    <div className="about container">
    <div><img className="main__img" src={currentData.strDrinkThumb}  alt="sda"/></div> 
    <div className="about__right">
      <h1 className="about__title">{currentData.strGlass}</h1>
      {<p className="about__p"><span>Description: </span>{currentData.strInstructions}</p>}
     { <p className="about__p"><span>Category: </span>{currentData.strCategory}</p>}
     <button type="button" class="btn btn-success">Order now</button>
    </div>
    </div>
    
  );
};

export default About;
